package com.kai.assistant

enum class Kind { WAKE, OPEN, OPEN_FAIL, DONE, NEED_ACC, UNKNOWN, STARTED, HOW, WHO, THANKS, TIME, JOKE }

/** Kaira ka swabhav: teen personality, har ek ke apne jawab. {a} ki jagah app ka naam / time aata hai. */
object Personality {

    private val dost = mapOf(
        Kind.WAKE to listOf("Haan boss, bolo", "Ji, sun raha hoon", "Boliye, main yahin hoon"),
        Kind.OPEN to listOf("Theek hai, {a} khol raha hoon", "{a} khul raha hai boss"),
        Kind.OPEN_FAIL to listOf("Mujhe {a} naam ka app nahi mila"),
        Kind.DONE to listOf("Ho gaya", "Kar diya boss"),
        Kind.NEED_ACC to listOf("Pehle accessibility on karo, phir main kaam karunga"),
        Kind.UNKNOWN to listOf("Samajh nahi aaya, dobara bolo"),
        Kind.STARTED to listOf("Kaira chalu ho gaya. Hey Kaira bolke mujhe bulao"),
        Kind.HOW to listOf("Main ekdum mast hoon, tum batao"),
        Kind.WHO to listOf("Main Kaira hoon, tumhara apna voice assistant"),
        Kind.THANKS to listOf("Koi baat nahi boss"),
        Kind.TIME to listOf("Abhi {a} hue hain"),
        Kind.JOKE to listOf(
            "Mobile ne WiFi se kaha, tum bina tar ke bhi mere dil se jude ho",
            "Pappu ne charger se kaha, tum na hote to main kab ka band ho jata"
        )
    )

    private val pro = mapOf(
        Kind.WAKE to listOf("Ji, boliye", "Main sun raha hoon"),
        Kind.OPEN to listOf("{a} khola ja raha hai"),
        Kind.OPEN_FAIL to listOf("{a} naam ka application uplabdh nahi hai"),
        Kind.DONE to listOf("Kaam poora hua"),
        Kind.NEED_ACC to listOf("Kripya pehle accessibility chalu karein"),
        Kind.UNKNOWN to listOf("Command samajh nahi aayi, kripya dobara boliye"),
        Kind.STARTED to listOf("Kaira taiyar hai"),
        Kind.HOW to listOf("Main bilkul theek hoon, dhanyavad"),
        Kind.WHO to listOf("Main Kaira hoon, aapka voice assistant"),
        Kind.THANKS to listOf("Aapka swagat hai"),
        Kind.TIME to listOf("Is samay {a} hue hain"),
        Kind.JOKE to listOf("Maaf kijiye, abhi mere paas koi achha chutkula nahi hai")
    )

    private val funny = mapOf(
        Kind.WAKE to listOf("Aapka hukm mere sar aankhon par", "Haan haan bolo, kaan khade hain mere"),
        Kind.OPEN to listOf("{a}? Abhi lo, ek second", "{a} aa raha hai, saans to lene do"),
        Kind.OPEN_FAIL to listOf("{a} kaun hai? Mere phone me to hai hi nahi"),
        Kind.DONE to listOf("Ho gaya, ab tareef to banti hai", "Ek dum jhakaas kaam"),
        Kind.NEED_ACC to listOf("Accessibility on karo yaar, haath bandhe hain mere"),
        Kind.UNKNOWN to listOf("Ye kya bola, mere sar ke upar se gaya"),
        Kind.STARTED to listOf("Kaira aa gaya, ab party shuru"),
        Kind.HOW to listOf("Battery full, dimaag half, mast hoon"),
        Kind.WHO to listOf("Main Kaira, tumhara sabse tez aur sabse sasta naukar"),
        Kind.THANKS to listOf("Arre shukriya kis baat ka, bas chai pila dena"),
        Kind.TIME to listOf("Ghadi bol rahi hai, {a} hue hain"),
        Kind.JOKE to listOf(
            "Doctor ne bola mobile kam chalao, maine bola doctor sahab, aap bhi to message dekhte ho",
            "Mera WiFi aur meri girlfriend, dono door jaate hi disconnect ho jate hain"
        )
    )

    fun reply(kind: Kind, arg: String = ""): String {
        val m = when (KaiState.persona) { 1 -> pro; 2 -> funny; else -> dost }
        val list = m[kind] ?: dost[kind] ?: return ""
        return list.random().replace("{a}", arg)
    }
}
