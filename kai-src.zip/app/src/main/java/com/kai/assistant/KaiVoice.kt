package com.kai.assistant

import android.content.Context
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Kai ki awaaz (Text-to-Speech). Bolte waqt speaking = true, character ka muh hilta hai. */
object KaiVoice {
    @Volatile private var rawSpeaking = false
    @Volatile private var startedAt = 0L
    // Agar TTS "khatam" signal na de to 10 sec baad apne aap false (warna mic kabhi sunta hi nahi)
    var speaking: Boolean
        get() = rawSpeaking && SystemClock.uptimeMillis() - startedAt < 10000
        set(v) { rawSpeaking = v; if (v) startedAt = SystemClock.uptimeMillis() }
    @Volatile var lastEnd = 0L
    @Volatile private var ready = false
    private var tts: TextToSpeech? = null
    private val pending = ArrayList<String>()

    private fun ensure(ctx: Context) {
        if (tts != null) return
        tts = TextToSpeech(ctx.applicationContext) { status ->
            val t = tts
            if (status == TextToSpeech.SUCCESS && t != null) {
                val r = t.setLanguage(Locale("en", "IN"))
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    t.setLanguage(Locale.US)
                }
                t.setPitch(1.2f)        // mulayam (female) awaaz
                t.setSpeechRate(1.0f)
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { speaking = true }
                    override fun onDone(utteranceId: String?) { finish() }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { finish() }
                })
                ready = true
                synchronized(pending) {
                    pending.forEach { speakNow(it) }
                    pending.clear()
                }
            }
        }
    }

    private fun finish() {
        speaking = false
        lastEnd = SystemClock.uptimeMillis()
    }

    private fun speakNow(text: String) {
        speaking = true
        val r = tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kai")
        if (r != TextToSpeech.SUCCESS) finish()
    }

    fun say(ctx: Context, text: String) {
        if (text.isEmpty()) return
        KaiState.lastLine = text
        if (!KaiState.voiceOn) return
        ensure(ctx)
        if (ready) speakNow(text) else synchronized(pending) { pending.add(text) }
    }
}
