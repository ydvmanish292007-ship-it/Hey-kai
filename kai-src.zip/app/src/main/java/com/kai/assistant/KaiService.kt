package com.kai.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast

class KaiService : Service() {

    companion object {
        @Volatile
        var isRunning = false
    }

    private var recognizer: SpeechRecognizer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var running = false

    // "hey kai" ke alag alag sunai dene wale roop
    // "hey" bolna zaroori nahi: sirf "kaira open whatsapp" bhi chalega
    private val wakeRegex = Regex("\\b(?:(?:hey|hay|hi|ok|okay|he|a)\\s+)?(?:kaira|kyra|kira|kara|kaara|kaera|kaaira|cara|kaila|kyla|kai|kay|kaye|kae|kaai|kei|kaay)\\b")

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        KaiState.load(this)
        isRunning = true
        if (!running) {
            running = true
            KaiVoice.say(this, Personality.reply(Kind.STARTED))
            startListening()
        }
        return START_STICKY
    }

    private fun startAsForeground() {
        val channelId = "kai"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Kai", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, channelId)
            .setContentTitle("Kai sun raha hai")
            .setContentText("\"Hey Kai\" bolo")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    private fun startListening() {
        if (!running) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Phone me speech service nahi mili. Google app install/update karo", Toast.LENGTH_LONG).show()
            restartSoon(5000)
            return
        }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Mic permission do (Setup page)", Toast.LENGTH_LONG).show()
            restartSoon(5000)
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(listener)
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN") // Hinglish ke liye theek chalta hai
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1800L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 4000L)
        }
        muteBeep(true)
        recognizer?.startListening(i)
        handler.postDelayed({ muteBeep(false) }, 900)
    }

    private fun restartSoon(delay: Long = 400) {
        handler.postDelayed({
            // Kai bol rahi ho to khatam hone tak ruko (mic on-off na ho)
            if (KaiVoice.speaking) restartSoon(300) else startListening()
        }, delay)
    }

    private var muted = false
    private fun muteBeep(mute: Boolean) {
        if (muted == mute) return
        try {
            val am = getSystemService(AudioManager::class.java)
            val flag = if (mute) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE
            am.adjustStreamVolume(AudioManager.STREAM_SYSTEM, flag, 0)
            am.adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, flag, 0)
            muted = mute
        } catch (e: Exception) {
        }
    }

    private val listener = object : RecognitionListener {
        override fun onResults(results: Bundle?) {
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                ?.lowercase()
                ?.trim()
            if (!text.isNullOrEmpty()) process(text)
            restartSoon()
        }

        override fun onError(error: Int) {
            // 6 = kuch bola nahi, 7 = samajh nahi aaya (normal). Baaki errors dikhao.
            if (error != 6 && error != 7 && error != 8) {
                Toast.makeText(this@KaiService, "Kai error code: $error", Toast.LENGTH_SHORT).show()
            }
            restartSoon(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 400)
        }

        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun process(text: String) {
        // Kai khud bol raha ho to apni hi awaaz mat suno
        KaiState.lastHeard = text
        if (KaiVoice.speaking || SystemClock.uptimeMillis() - KaiVoice.lastEnd < 800) return
        Toast.makeText(this, "Suna: $text", Toast.LENGTH_SHORT).show()

        val match = wakeRegex.find(text)
        when {
            match != null -> {
                val command = text.substring(match.range.last + 1).trim()
                if (command.isEmpty()) {
                    KaiState.awaitUntil = System.currentTimeMillis() + 9000
                    if (KaiState.voiceOn) KaiVoice.say(this, Personality.reply(Kind.WAKE)) else beep()
                } else {
                    CommandHandler.handle(this, command)
                }
            }
            KaiState.awaiting -> CommandHandler.handle(this, text)
            // Wake word chhoot gaya ho, phir bhi seedha "open ..." / "... kholo" chal jaye
            Regex("^(open|launch|start)\\s+.+|.+\\s+(kholo|khol do|chalu karo)$").containsMatchIn(text) ->
                CommandHandler.handle(this, text)
        }
    }

    private fun beep() {
        ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 150)
    }

    override fun onDestroy() {
        muteBeep(false)
        running = false
        isRunning = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        super.onDestroy()
    }
}
