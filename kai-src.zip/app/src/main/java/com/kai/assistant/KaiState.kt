package com.kai.assistant

import android.content.Context
import android.graphics.Color

/** Poore app ki shared state: rang, personality, voice on/off, kya bola/suna. */
object KaiState {
    @Volatile var awaitUntil = 0L
    @Volatile var lastLine = ""
    @Volatile var lastHeard = ""
    @Volatile var themeIndex = 0
    @Volatile var persona = 0
    @Volatile var voiceOn = true

    val themes = intArrayOf(
        Color.parseColor("#00E5FF"), Color.parseColor("#B388FF"),
        Color.parseColor("#FF5252"), Color.parseColor("#FFC400")
    )
    val personaNames = listOf("Dost", "Professional", "Mazaakiya")

    val awaiting: Boolean get() = System.currentTimeMillis() < awaitUntil
    val themeColor: Int get() = themes[themeIndex.coerceIn(0, themes.size - 1)]

    fun load(ctx: Context) {
        val p = ctx.getSharedPreferences("kai", Context.MODE_PRIVATE)
        themeIndex = p.getInt("theme", 0)
        persona = p.getInt("persona", 0)
        voiceOn = p.getBoolean("voice", true)
    }

    fun save(ctx: Context) {
        ctx.getSharedPreferences("kai", Context.MODE_PRIVATE).edit()
            .putInt("theme", themeIndex).putInt("persona", persona).putBoolean("voice", voiceOn).apply()
    }
}
