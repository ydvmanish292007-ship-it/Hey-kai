package com.kai.assistant

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.widget.Toast
import org.json.JSONObject
import java.util.Calendar

object CommandHandler {

    private fun say(ctx: Context, kind: Kind, arg: String = "") =
        KaiVoice.say(ctx, Personality.reply(kind, arg))

    fun handle(ctx: Context, raw: String) {
        val t = raw.trim().lowercase()
        KaiState.awaitUntil = 0
        KaiState.chatKeep = false
        KaiState.lastHeard = t
        Toast.makeText(ctx, "Kai: $t", Toast.LENGTH_SHORT).show()

        // --- Baatcheet band ---
        if (t in listOf("bye", "bye bye", "bas", "bas kar", "chup", "stop", "ruko", "band karo", "good night", "ok bye")) {
            say(ctx, Kind.THANKS)
            return
        }

        // --- Baatcheet ---
        if (smallTalk(ctx, t)) return

        // --- App kholna: "open instagram" ya "instagram kholo" ---
        Regex("^(open|launch|start)\\s+(.+)$").find(t)?.let {
            if (simpleName(it.groupValues[2])) { openApp(ctx, KaiAccessibilityService.instance, it.groupValues[2]); return }
        }
        Regex("^(.+?)\\s+(kholo|khol do|khol|chalu karo|chalao)$").find(t)?.let {
            if (simpleName(it.groupValues[1])) { openApp(ctx, KaiAccessibilityService.instance, it.groupValues[1]); return }
        }

        // --- Accessibility wale kaam ---
        val acc = KaiAccessibilityService.instance
        if (acc == null) {
            say(ctx, Kind.NEED_ACC)
            return
        }
        val ok = when {
            t in listOf("back", "go back", "peeche", "wapas") -> acc.back()
            t in listOf("home", "go home", "ghar") -> acc.home()
            t in listOf("recents", "recent apps", "multitask") -> acc.recents()
            t in listOf("notifications", "notification kholo", "open notifications") -> acc.notifications()
            t.startsWith("scroll down") || t.startsWith("neeche") -> { acc.scroll(true); true }
            t.startsWith("scroll up") || t.startsWith("upar") -> { acc.scroll(false); true }
            t.startsWith("click ") -> acc.clickText(t.removePrefix("click ").trim())
            t.startsWith("tap ") -> acc.clickText(t.removePrefix("tap ").trim())
            t.startsWith("type ") -> acc.typeText(t.removePrefix("type ").trim())
            else -> null
        }
        when (ok) {
            null -> agent(ctx, t)
            true -> say(ctx, Kind.DONE)
            false -> say(ctx, Kind.UNKNOWN)
        }
    }

    /** "open youtube" simple hai; "open youtube aur search karo" lambi command hai -> AI */
    private fun simpleName(n: String): Boolean {
        val w = n.trim().split(" ")
        if (w.size > 3) return false
        val bad = listOf("search", "aur", "and", "phir", "then", "karo", "play", "chalao", "kholke", "khol", "dekho", "bhej", "send", "likh")
        return w.none { it in bad }
    }

    private fun smallTalk(ctx: Context, t: String): Boolean {
        when {
            "kaise ho" in t || "how are you" in t -> say(ctx, Kind.HOW)
            "tumhara naam" in t || "your name" in t || "who are you" in t || "tum kaun" in t -> say(ctx, Kind.WHO)
            "thank" in t || "shukriya" in t || "dhanyavad" in t -> say(ctx, Kind.THANKS)
            "joke" in t || "chutkula" in t -> say(ctx, Kind.JOKE)
            t == "time" || "what time" in t || "time kya" in t || "kitne baje" in t || "samay kya" in t -> {
                val c = Calendar.getInstance()
                var h = c.get(Calendar.HOUR)
                if (h == 0) h = 12
                say(ctx, Kind.TIME, "$h baj ke ${c.get(Calendar.MINUTE)} minute")
            }
            else -> return false
        }
        return true
    }

    private fun openApp(ctx: Context, acc: KaiAccessibilityService?, name: String, speak: Boolean = true): Boolean {
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, PackageManager.MATCH_ALL)

        fun norm(x: String) = x.lowercase().replace(Regex("[^a-z0-9\\u0900-\\u097F]"), "")
            .replace("app", "").replace("whats", "whats")
        val aliases = mapOf(
            "insta" to "instagram", "gram" to "instagram", "इंस्टाग्राम" to "instagram",
            "व्हाट्सएप" to "whatsapp", "वॉट्सऐप" to "whatsapp", "whatsap" to "whatsapp", "watsapp" to "whatsapp",
            "yt" to "youtube", "यूट्यूब" to "youtube", "chrome" to "chrome", "क्रोम" to "chrome"
        )
        val q0 = name.trim().lowercase().removePrefix("the ").removeSuffix(" app").trim()
        val query = aliases[norm(q0)] ?: q0
        val nq = norm(query)
        val hit = apps.firstOrNull { norm(it.loadLabel(pm).toString()) == nq }
            ?: apps.firstOrNull { norm(it.loadLabel(pm).toString()).contains(nq) && nq.length >= 3 }
            ?: apps.firstOrNull { nq.contains(norm(it.loadLabel(pm).toString())) && norm(it.loadLabel(pm).toString()).length >= 4 }

        if (hit == null) {
            if (speak) say(ctx, Kind.OPEN_FAIL, query)
            return false
        }
        val intent = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
            ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (intent == null) {
            if (speak) say(ctx, Kind.OPEN_FAIL, query)
            return false
        }
        if (speak) say(ctx, Kind.OPEN, hit.loadLabel(pm).toString())
        // Android 10+ me background se activity start block hoti hai,
        // accessibility service us restriction se bahar hai.
        (acc ?: ctx).startActivity(intent)
        return true
    }

    // ---------- AI mode: jo fixed commands me nahi mila, Claude ko do ----------
    private fun agent(ctx: Context, command: String) {
        val key = AiBrain.key(ctx)
        AiBrain.loadModel(ctx)
        AiBrain.userName = ctx.getSharedPreferences("kai", Context.MODE_PRIVATE).getString("name", "") ?: ""
        if (key.isEmpty()) {
            say(ctx, Kind.UNKNOWN)
            return
        }
        KaiState.lastLine = "\uD83E\uDD14 Soch raha hoon..."
        Thread {
            var history = ""
            for (step in 1..4) {
                val acc = KaiAccessibilityService.instance
                val screen = acc?.screenText() ?: ""
                val plan = AiBrain.plan(key, command, screen, history)
                if (plan == null) {
                    KaiVoice.say(ctx, AiBrain.lastError)
                    return@Thread
                }
                if (step == 1) {
                    AiBrain.remember(command, plan.say)
                    // Sirf baatcheet thi (koi kaam nahi) to jawab ke baad bhi sunte raho
                    KaiState.chatKeep = plan.actions.isEmpty()
                }
                if (plan.say.isNotEmpty()) KaiVoice.say(ctx, plan.say)
                for (a in plan.actions) {
                    history += runAction(ctx, KaiAccessibilityService.instance, a) + "; "
                    Thread.sleep(700)
                }
                if (!plan.more || plan.actions.isEmpty()) break
                Thread.sleep(1500)
            }
        }.start()
    }

    private fun runAction(ctx: Context, acc: KaiAccessibilityService?, a: JSONObject): String {
        val type = a.optString("type")
        val ok = when (type) {
            "open_app" -> openApp(ctx, acc, a.optString("name"), false)
            "back" -> acc?.back() ?: false
            "home" -> acc?.home() ?: false
            "recents" -> acc?.recents() ?: false
            "notifications" -> acc?.notifications() ?: false
            "scroll" -> { acc?.scroll(a.optString("dir") != "up"); acc != null }
            "click" -> acc?.clickText(a.optString("text")) ?: false
            "type" -> acc?.typeText(a.optString("text")) ?: false
            "enter" -> acc?.pressEnter() ?: false
            "open_url" -> acc?.openUrl(a.optString("url")) ?: false
            "wait" -> true
            else -> false
        }
        return "$type ${a.optString("name")}${a.optString("text")} -> " + if (ok) "ok" else "failed"
    }
}
