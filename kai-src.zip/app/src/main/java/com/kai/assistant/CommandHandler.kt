package com.kai.assistant

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.widget.Toast
import java.util.Calendar

object CommandHandler {

    private fun say(ctx: Context, kind: Kind, arg: String = "") =
        KaiVoice.say(ctx, Personality.reply(kind, arg))

    fun handle(ctx: Context, raw: String) {
        val t = raw.trim().lowercase()
        KaiState.awaitUntil = 0
        KaiState.lastHeard = t
        Toast.makeText(ctx, "Kai: $t", Toast.LENGTH_SHORT).show()

        // --- Baatcheet ---
        if (smallTalk(ctx, t)) return

        // --- App kholna: "open instagram" ya "instagram kholo" ---
        Regex("^(open|launch|start)\\s+(.+)$").find(t)?.let {
            openApp(ctx, KaiAccessibilityService.instance, it.groupValues[2]); return
        }
        Regex("^(.+?)\\s+(kholo|khol do|khol|chalu karo|chalao)$").find(t)?.let {
            openApp(ctx, KaiAccessibilityService.instance, it.groupValues[1]); return
        }

        // --- Accessibility wale kaam ---
        val acc = KaiAccessibilityService.instance
        if (acc == null) {
            say(ctx, Kind.NEED_ACC)
            return
        }
        val ok = when {
            t in listOf("back", "go back", "peeche", "wapas") -> acc.back()
            t in listOf("home", "go home", "ghar") -> acc.home()
            t in listOf("recents", "recent apps", "multitask") -> acc.recents()
            t in listOf("notifications", "notification kholo", "open notifications") -> acc.notifications()
            t.startsWith("scroll down") || t.startsWith("neeche") -> { acc.scroll(true); true }
            t.startsWith("scroll up") || t.startsWith("upar") -> { acc.scroll(false); true }
            t.startsWith("click ") -> acc.clickText(t.removePrefix("click ").trim())
            t.startsWith("tap ") -> acc.clickText(t.removePrefix("tap ").trim())
            t.startsWith("type ") -> acc.typeText(t.removePrefix("type ").trim())
            else -> null
        }
        when (ok) {
            null -> say(ctx, Kind.UNKNOWN)
            true -> say(ctx, Kind.DONE)
            false -> say(ctx, Kind.UNKNOWN)
        }
    }

    private fun smallTalk(ctx: Context, t: String): Boolean {
        when {
            "kaise ho" in t || "how are you" in t -> say(ctx, Kind.HOW)
            "tumhara naam" in t || "your name" in t || "who are you" in t || "tum kaun" in t -> say(ctx, Kind.WHO)
            "thank" in t || "shukriya" in t || "dhanyavad" in t -> say(ctx, Kind.THANKS)
            "joke" in t || "chutkula" in t -> say(ctx, Kind.JOKE)
            t == "time" || "what time" in t || "time kya" in t || "kitne baje" in t || "samay kya" in t -> {
                val c = Calendar.getInstance()
                var h = c.get(Calendar.HOUR)
                if (h == 0) h = 12
                say(ctx, Kind.TIME, "$h baj ke ${c.get(Calendar.MINUTE)} minute")
            }
            else -> return false
        }
        return true
    }

    private fun openApp(ctx: Context, acc: KaiAccessibilityService?, name: String) {
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, PackageManager.MATCH_ALL)

        fun norm(x: String) = x.lowercase().replace(Regex("[^a-z0-9\\u0900-\\u097F]"), "")
            .replace("app", "").replace("whats", "whats")
        val aliases = mapOf(
            "insta" to "instagram", "gram" to "instagram", "इंस्टाग्राम" to "instagram",
            "व्हाट्सएप" to "whatsapp", "वॉट्सऐप" to "whatsapp", "whatsap" to "whatsapp", "watsapp" to "whatsapp",
            "yt" to "youtube", "यूट्यूब" to "youtube", "chrome" to "chrome", "क्रोम" to "chrome"
        )
        val q0 = name.trim().lowercase().removePrefix("the ").removeSuffix(" app").trim()
        val query = aliases[norm(q0)] ?: q0
        val nq = norm(query)
        val hit = apps.firstOrNull { norm(it.loadLabel(pm).toString()) == nq }
            ?: apps.firstOrNull { norm(it.loadLabel(pm).toString()).contains(nq) && nq.length >= 3 }
            ?: apps.firstOrNull { nq.contains(norm(it.loadLabel(pm).toString())) && norm(it.loadLabel(pm).toString()).length >= 4 }

        if (hit == null) {
            say(ctx, Kind.OPEN_FAIL, query)
            return
        }
        val intent = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
            ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (intent == null) {
            say(ctx, Kind.OPEN_FAIL, query)
            return
        }
        say(ctx, Kind.OPEN, hit.loadLabel(pm).toString())
        // Android 10+ me background se activity start block hoti hai,
        // accessibility service us restriction se bahar hai.
        (acc ?: ctx).startActivity(intent)
    }
}
