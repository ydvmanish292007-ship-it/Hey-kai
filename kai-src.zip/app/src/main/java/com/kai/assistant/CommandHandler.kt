package com.kai.assistant

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.widget.Toast
import java.util.Calendar

object CommandHandler {

    private fun say(ctx: Context, kind: Kind, arg: String = "") =
        KaiVoice.say(ctx, Personality.reply(kind, arg))

    fun handle(ctx: Context, raw: String) {
        val t = raw.trim().lowercase()
        KaiState.awaitUntil = 0
        KaiState.lastHeard = t
        Toast.makeText(ctx, "Kai: $t", Toast.LENGTH_SHORT).show()

        // --- Baatcheet ---
        if (smallTalk(ctx, t)) return

        // --- App kholna: "open instagram" ya "instagram kholo" ---
        Regex("^(open|launch|start)\\s+(.+)$").find(t)?.let {
            openApp(ctx, KaiAccessibilityService.instance, it.groupValues[2]); return
        }
        Regex("^(.+?)\\s+(kholo|khol do|khol|chalu karo|chalao)$").find(t)?.let {
            openApp(ctx, KaiAccessibilityService.instance, it.groupValues[1]); return
        }

        // --- Accessibility wale kaam ---
        val acc = KaiAccessibilityService.instance
        if (acc == null) {
            say(ctx, Kind.NEED_ACC)
            return
        }
        val ok = when {
            t in listOf("back", "go back", "peeche", "wapas") -> acc.back()
            t in listOf("home", "go home", "ghar") -> acc.home()
            t in listOf("recents", "recent apps", "multitask") -> acc.recents()
            t in listOf("notifications", "notification kholo", "open notifications") -> acc.notifications()
            t.startsWith("scroll down") || t.startsWith("neeche") -> { acc.scroll(true); true }
            t.startsWith("scroll up") || t.startsWith("upar") -> { acc.scroll(false); true }
            t.startsWith("click ") -> acc.clickText(t.removePrefix("click ").trim())
            t.startsWith("tap ") -> acc.clickText(t.removePrefix("tap ").trim())
            t.startsWith("type ") -> acc.typeText(t.removePrefix("type ").trim())
            else -> null
        }
        when (ok) {
            null -> say(ctx, Kind.UNKNOWN)
            true -> say(ctx, Kind.DONE)
            false -> say(ctx, Kind.UNKNOWN)
        }
    }

    private fun smallTalk(ctx: Context, t: String): Boolean {
        when {
            "kaise ho" in t || "how are you" in t -> say(ctx, Kind.HOW)
            "tumhara naam" in t || "your name" in t || "who are you" in t || "tum kaun" in t -> say(ctx, Kind.WHO)
            "thank" in t || "shukriya" in t || "dhanyavad" in t -> say(ctx, Kind.THANKS)
            "joke" in t || "chutkula" in t -> say(ctx, Kind.JOKE)
            t == "time" || "what time" in t || "time kya" in t || "kitne baje" in t || "samay kya" in t -> {
                val c = Calendar.getInstance()
                var h = c.get(Calendar.HOUR)
                if (h == 0) h = 12
                say(ctx, Kind.TIME, "$h baj ke ${c.get(Calendar.MINUTE)} minute")
            }
            else -> return false
        }
        return true
    }

    private fun openApp(ctx: Context, acc: KaiAccessibilityService?, name: String) {
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, PackageManager.MATCH_ALL)

        val query = name.trim()
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().equals(query, true) }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().contains(query, true) }

        if (hit == null) {
            say(ctx, Kind.OPEN_FAIL, query)
            return
        }
        val intent = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
            ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (intent == null) {
            say(ctx, Kind.OPEN_FAIL, query)
            return
        }
        say(ctx, Kind.OPEN, hit.loadLabel(pm).toString())
        // Android 10+ me background se activity start block hoti hai,
        // accessibility service us restriction se bahar hai.
        (acc ?: ctx).startActivity(intent)
    }
}
