package com.kai.assistant

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.widget.Toast

object CommandHandler {

    fun handle(ctx: Context, raw: String) {
        val t = raw.trim().lowercase()
        val acc = KaiAccessibilityService.instance
        Toast.makeText(ctx, "Kai: $t", Toast.LENGTH_SHORT).show()

        // --- App kholna: "open instagram" ya "instagram kholo" ---
        Regex("^(open|launch|start)\\s+(.+)$").find(t)?.let {
            openApp(ctx, acc, it.groupValues[2]); return
        }
        Regex("^(.+?)\\s+(kholo|khol do|khol|chalu karo|chalao)$").find(t)?.let {
            openApp(ctx, acc, it.groupValues[1]); return
        }

        // --- Accessibility wale kaam ---
        if (acc == null) {
            Toast.makeText(ctx, "Accessibility ON nahi hai", Toast.LENGTH_LONG).show()
            return
        }
        when {
            t in listOf("back", "go back", "peeche", "wapas") -> acc.back()
            t in listOf("home", "go home", "ghar") -> acc.home()
            t in listOf("recents", "recent apps", "multitask") -> acc.recents()
            t in listOf("notifications", "notification kholo", "open notifications") -> acc.notifications()
            t.startsWith("scroll down") || t.startsWith("neeche") -> acc.scroll(down = true)
            t.startsWith("scroll up") || t.startsWith("upar") -> acc.scroll(down = false)
            t.startsWith("click ") -> acc.clickText(t.removePrefix("click ").trim())
            t.startsWith("tap ") -> acc.clickText(t.removePrefix("tap ").trim())
            t.startsWith("type ") -> acc.typeText(t.removePrefix("type ").trim())
            else -> Toast.makeText(ctx, "Samajh nahi aaya: $t", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openApp(ctx: Context, acc: KaiAccessibilityService?, name: String) {
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, PackageManager.MATCH_ALL)

        val query = name.trim()
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().equals(query, true) }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().contains(query, true) }

        if (hit == null) {
            Toast.makeText(ctx, "App nahi mila: $query", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
            ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) ?: return

        // Android 10+ me background se activity start block hoti hai,
        // accessibility service us restriction se bahar hai.
        (acc ?: ctx).startActivity(intent)
    }
}
