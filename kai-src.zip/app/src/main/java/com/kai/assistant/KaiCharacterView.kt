package com.kai.assistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Kai: anime AI girl (photo) + neon glow, rings aur awaaz bars.
 * - Neon aankhein: band = dim, sunta hua = theme rang, command ka intezaar = hara, bolte waqt = gulabi + pulse
 * - Bolte waqt muh hilta hai (KaiVoice.speaking)
 * - Tairta hai, saans leta hai, palak jhapakta hai, tap par uchhalta hai
 */
class KaiCharacterView(ctx: Context) : View(ctx) {

    var active = false
    private var tapTime = -10000L

    fun poke() { tapTime = SystemClock.uptimeMillis() }

    private fun col(s: String) = Color.parseColor(s)
    private fun fill(c: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = c }
    private fun line(c: Int, w: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = c; style = Paint.Style.STROKE; strokeWidth = w; strokeCap = Paint.Cap.ROUND
    }

    private val pink = col("#FF4081")
    private val green = col("#00E676")
    private val offColor = col("#4A5280")

    private val skin = fill(col("#E8C3A8"))
    private val skinDark = fill(col("#CFA188"))
    private val jacket = fill(col("#141A38"))
    private val vneck = fill(col("#090D22"))
    private val socket = fill(col("#0B0F2A"))
    private val mouthIn = fill(col("#2A0F1F"))
    private val dark = fill(col("#0B0F2A"))
    private val neon = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val accentLine = line(Color.CYAN, 2f)
    private val ring = line(Color.CYAN, 1.6f)
    private val sparkle = fill(Color.WHITE)
    private val browPaint = line(col("#2B2F66"), 3.4f)
    private val mouthLine = line(col("#8A5A55"), 2.4f)
    private val noseLine = line(col("#B98B73"), 1.6f)
    private val cupFill = fill(col("#0F1430"))
    private val boom = line(Color.CYAN, 2.2f)

    private val hair = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = LinearGradient(0f, 28f, 0f, 112f, col("#6C63FF"), col("#12163A"), Shader.TileMode.CLAMP)
    }

    private val hairBack = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = LinearGradient(0f, 70f, 0f, 245f, col("#4A3394"), col("#150F33"), Shader.TileMode.CLAMP)
    }
    private val sareePink = fill(col("#FF6FA8"))
    private val sareeDeep = fill(col("#E91E75"))
    private val blouse = fill(col("#FFE0EC"))
    private val gold = line(col("#FFD54F"), 2f)
    private val goldFill = fill(col("#FFD54F"))
    private val sclera = fill(col("#FBF7FF"))
    private val white = fill(Color.WHITE)
    private val lash = line(col("#1B1233"), 3.4f)
    private val blush = fill(col("#FF8FB3")).apply { alpha = 120 }
    private val bindi = fill(col("#E53935"))
    private val petal = fill(col("#FFB3D1"))
    private val tongue = fill(col("#FF7A9C"))

    private val girl: Bitmap? by lazy {
        try { BitmapFactory.decodeResource(resources, R.drawable.kai_girl) } catch (e: Exception) { null }
    }
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val bar = fill(Color.WHITE)

    private val ringA = RectF(8f, 38f, 192f, 222f)
    private val ringB = RectF(20f, 50f, 180f, 210f)
    private val path = Path()

    private fun sf(x: Double) = sin(x).toFloat()

    private fun neonPaint(c: Int, a: Int): Paint {
        neon.color = c
        neon.alpha = a.coerceIn(0, 255)
        return neon
    }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val t = now / 1000.0
        val spk = KaiVoice.speaking
        val aw = KaiState.awaiting
        val run = KaiService.isRunning

        val eye = when {
            spk -> pink
            aw -> green
            run -> KaiState.themeColor
            else -> offColor
        }

        val s = min(width / 200f, height / 260f)
        c.save()
        c.translate((width - 200f * s) / 2f, (height - 260f * s) / 2f)
        c.scale(s, s)

        // Glow + ghoomti rings
        glow.color = eye
        for (k in 1..4) {
            glow.alpha = if (run || spk) 16 else 8
            c.drawCircle(100f, 130f, 114f - k * 14f, glow)
        }
        ring.color = eye
        ring.alpha = 70
        c.drawCircle(100f, 130f, 92f, ring)
        ring.alpha = 220
        val speedUp = if (spk) 2.2 else 1.0
        c.drawArc(ringA, (t * 40 * speedUp).toFloat(), 70f, false, ring)
        c.drawArc(ringA, (t * 40 * speedUp + 180).toFloat(), 40f, false, ring)
        c.drawArc(ringB, (-t * 55 * speedUp).toFloat(), 60f, false, ring)

        // Data sparkles
        for (i in 0..7) {
            val a = i * 0.8 + t * 0.3 * (if (i % 2 == 0) 1 else -1)
            val r = 96f + (i % 3) * 8f
            val x = 100f + r * cos(a).toFloat()
            val y = 130f + r * 1.05f * sin(a).toFloat()
            sparkle.color = eye
            sparkle.alpha = (120 + 120 * sin(t * 2 + i)).toInt().coerceIn(0, 255)
            c.drawCircle(x, y, 1.4f + (i % 3) * 0.6f, sparkle)
        }

        // Tap par uchhalna
        val dt = now - tapTime
        var jump = 0f
        var surprise = 0f
        if (dt in 0L..700L) {
            val k = dt / 700.0
            jump = (-abs(sin(k * PI * 2)) * 16 * (1 - k)).toFloat()
            surprise = (1 - k).toFloat() * 0.8f
        }
        val bob = sf(t * 1.6) * 4f + jump
        val breath = 1f + 0.006f * sf(t * 2.0)

        c.save()
        c.translate(0f, bob)
        c.scale(1f, breath, 100f, 262f)

        // Kai ki photo (halka tairna + saans + bolte waqt halka pulse)
        val pulse = if (spk) 1f + 0.012f * sf(t * 12) else 1f
        c.save()
        c.scale(pulse, pulse, 100f, 140f)
        girl?.let { c.drawBitmap(it, null, RectF(35f, 6f, 165f, 256f), bmpPaint) }
        c.restore()

        // Bolte waqt awaaz ki bars
        if (spk) {
            for (i in 0..8) {
                val hh = 4f + 14f * abs(sf(t * 9 + i * 0.9)) * (0.6f + 0.4f * sf(t * 2.3 + i))
                bar.color = eye
                bar.alpha = 220
                c.drawRoundRect(RectF(52f + i * 11f, 250f - hh, 57f + i * 11f, 250f), 2f, 2f, bar)
            }
        }
        if (aw && !spk) {
            c.drawCircle(100f, 252f, 3f + 1.5f * sf(t * 6), neonPaint(green, 255))
        }

        c.restore()
        c.restore()
        postInvalidateOnAnimation()
    }
}
