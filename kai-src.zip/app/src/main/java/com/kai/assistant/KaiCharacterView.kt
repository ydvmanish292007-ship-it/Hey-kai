package com.kai.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Kai ka animated character: tairta hai, palak jhapakta hai, saans leta hai, sunte waqt muh hilata hai. */
class KaiCharacterView(ctx: Context) : View(ctx) {

    var active = false
    private var tapTime = -10000L

    fun poke() { tapTime = SystemClock.uptimeMillis() }

    private fun col(s: String) = Color.parseColor(s)
    private fun fill(c: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = c }
    private fun line(c: Int, w: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = c; style = Paint.Style.STROKE; strokeWidth = w; strokeCap = Paint.Cap.ROUND
    }

    private val cyan = col("#00E5FF")
    private val green = col("#00E676")

    private val skin = fill(col("#FFE2D2"))
    private val skinDark = fill(col("#F4C6B2"))
    private val white = fill(Color.WHITE)
    private val navy = fill(col("#1B2250"))
    private val jacket = fill(col("#EDEBFF"))
    private val blush = fill(col("#66FF6FA5"))
    private val dark = fill(col("#1A1233"))
    private val mouthIn = fill(col("#C2415A"))
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = line(cyan, 1.6f)
    private val sparkle = fill(Color.WHITE)
    private val lash = line(col("#2A1B5E"), 2.6f)
    private val brow = line(col("#5B3FD1"), 2f)
    private val mouthLine = line(col("#B5445F"), 2.2f)
    private val cupStroke = line(cyan, 2f)
    private val band = line(cyan, 4.5f)
    private val trim = line(cyan, 2f)
    private val hairHi = line(col("#80FFFFFF"), 2f)

    private val hair = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = LinearGradient(
            40f, 40f, 160f, 230f,
            intArrayOf(col("#7C4DFF"), col("#2979FF"), col("#00E5FF")),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
    }
    private val iris = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = LinearGradient(0f, -14f, 0f, 14f, col("#00E5FF"), col("#7C4DFF"), Shader.TileMode.CLAMP)
    }
    private val glowC = RadialGradient(100f, 130f, 112f, col("#4400E5FF"), Color.TRANSPARENT, Shader.TileMode.CLAMP)
    private val glowG = RadialGradient(100f, 130f, 112f, col("#4400E676"), Color.TRANSPARENT, Shader.TileMode.CLAMP)

    private val ringA = RectF(8f, 38f, 192f, 222f)
    private val ringB = RectF(20f, 50f, 180f, 210f)
    private val path = Path()

    private fun sf(x: Double) = sin(x).toFloat()

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val t = now / 1000.0
        val s = min(width / 200f, height / 260f)
        c.save()
        c.translate((width - 200f * s) / 2f, (height - 260f * s) / 2f)
        c.scale(s, s)

        val accent = if (active) green else cyan

        // Glow + ghoomti rings
        glow.shader = if (active) glowG else glowC
        c.drawCircle(100f, 130f, 112f, glow)
        ring.color = accent
        ring.alpha = 70
        c.drawCircle(100f, 130f, 92f, ring)
        ring.alpha = 220
        c.drawArc(ringA, (t * 40).toFloat(), 70f, false, ring)
        c.drawArc(ringA, (t * 40 + 180).toFloat(), 40f, false, ring)
        c.drawArc(ringB, (-t * 55).toFloat(), 60f, false, ring)

        // Chamakte sparkles
        for (i in 0..7) {
            val a = i * 0.8 + t * 0.3 * (if (i % 2 == 0) 1 else -1)
            val r = 96f + (i % 3) * 8f
            val x = 100f + r * cos(a).toFloat()
            val y = 130f + r * 1.05f * sin(a).toFloat()
            sparkle.alpha = (120 + 120 * sin(t * 2 + i)).toInt().coerceIn(0, 255)
            c.drawCircle(x, y, 1.4f + (i % 3) * 0.6f, sparkle)
        }

        // Tap karne par uchhalna
        val dt = now - tapTime
        var jump = 0f
        var surprise = 0f
        if (dt in 0L..700L) {
            val k = dt / 700.0
            jump = (-abs(sin(k * PI * 2)) * 16 * (1 - k)).toFloat()
            surprise = (1 - k).toFloat() * 0.8f
        }
        val bob = sf(t * 1.6) * 4f + jump
        val breath = 1f + 0.006f * sf(t * 2.0)
        val sway = sf(t * 1.3) * 4f

        c.save()
        c.translate(0f, bob)
        c.scale(1f, breath, 100f, 262f)

        // Peeche ke baal
        c.drawOval(RectF(50f, 52f, 150f, 150f), hair)

        // Jacket
        path.reset()
        path.moveTo(40f, 262f)
        path.cubicTo(40f, 215f, 60f, 200f, 100f, 198f)
        path.cubicTo(140f, 200f, 160f, 215f, 160f, 262f)
        path.close()
        c.drawPath(path, jacket)
        c.drawPath(path, trim)
        path.reset()
        path.moveTo(80f, 200f); path.lineTo(100f, 232f); path.lineTo(120f, 200f); path.close()
        c.drawPath(path, navy)
        sparkle.color = accent
        sparkle.alpha = (150 + 100 * sin(t * 3)).toInt().coerceIn(0, 255)
        c.drawCircle(100f, 238f, 4f, sparkle)
        sparkle.color = Color.WHITE

        // Gardan
        c.drawRect(RectF(91f, 172f, 109f, 205f), skinDark)
        // Sar
        c.drawOval(RectF(54f, 66f, 146f, 174f), skin)

        // Aage ki lambi lat
        path.reset()
        path.moveTo(54f, 100f)
        path.cubicTo(34f, 140f, 36f, 190f, 50f + sway, 226f)
        path.cubicTo(64f + sway, 214f, 70f, 190f, 72f, 150f)
        path.close()
        c.drawPath(path, hair)
        path.reset()
        path.moveTo(146f, 100f)
        path.cubicTo(166f, 140f, 164f, 190f, 150f + sway, 226f)
        path.cubicTo(136f + sway, 214f, 130f, 190f, 128f, 150f)
        path.close()
        c.drawPath(path, hair)

        // Bangs
        path.reset()
        path.moveTo(52f, 112f)
        path.cubicTo(50f, 56f, 150f, 56f, 148f, 112f)
        path.lineTo(136f, 88f); path.lineTo(122f, 106f); path.lineTo(104f, 80f)
        path.lineTo(88f, 106f); path.lineTo(72f, 86f); path.lineTo(60f, 108f)
        path.close()
        c.drawPath(path, hair)
        c.drawArc(RectF(66f, 62f, 120f, 96f), 200f, 70f, false, hairHi)

        // Palak
        val m = now % 3800
        val open = if (m < 180) 1f - sf(PI * m / 180.0) else 1f
        val lx = sf(t * 0.8) * 1.5f
        for (ex in floatArrayOf(79f, 121f)) {
            val ey = 124f
            c.save()
            c.translate(ex, ey)
            c.scale(1f, max(open, 0.08f))
            c.drawOval(RectF(-12f, -15f, 12f, 15f), white)
            c.save()
            c.translate(lx, 0f)
            c.drawOval(RectF(-9.5f, -13f, 9.5f, 13f), iris)
            c.drawOval(RectF(-4.5f, -7f, 4.5f, 7f), dark)
            c.restore()
            c.drawArc(RectF(-12f, -15f, 12f, 15f), 195f, 150f, false, lash)
            c.restore()
            if (open > 0.5f) {
                c.drawCircle(ex + lx - 3f, ey - 5f, 3f, white)
                c.drawCircle(ex + lx + 3f, ey + 4f, 1.5f, white)
            }
            c.drawPath(Path().apply {
                moveTo(ex - 9f, ey - 20f); quadTo(ex, ey - 25f, ex + 9f, ey - 20f)
            }, brow)
        }

        // Gaal + naak
        c.drawOval(RectF(60f, 134f, 76f, 144f), blush)
        c.drawOval(RectF(124f, 134f, 140f, 144f), blush)
        c.drawCircle(100f, 139f, 1.1f, skinDark)

        // Muh: sunte waqt hilta hai
        val mouth = max(surprise, if (active) 0.25f + 0.25f * sf(t * 6) else 0f)
        if (mouth < 0.08f) {
            c.drawArc(RectF(92f, 143f, 108f, 154f), 20f, 140f, false, mouthLine)
        } else {
            c.drawOval(RectF(94f, 146f, 106f, 146f + 3f + 9f * mouth), mouthIn)
        }

        // Headphones
        c.drawArc(RectF(48f, 46f, 152f, 166f), 180f, 180f, false, band)
        for (x in floatArrayOf(38f, 146f)) {
            c.drawRoundRect(RectF(x, 104f, x + 16f, 144f), 6f, 6f, navy)
            c.drawRoundRect(RectF(x, 104f, x + 16f, 144f), 6f, 6f, cupStroke)
            sparkle.color = accent
            sparkle.alpha = (140 + 110 * sin(t * 3)).toInt().coerceIn(0, 255)
            c.drawCircle(x + 8f, 124f, 3f, sparkle)
            sparkle.color = Color.WHITE
        }
        c.drawPath(Path().apply {
            moveTo(42f, 142f); quadTo(44f, 164f, 72f, 164f)
        }, line(cyan, 2.4f))
        c.drawCircle(72f, 164f, 3f, fill(cyan))

        c.restore()
        c.restore()
        postInvalidateOnAnimation()
    }
}
