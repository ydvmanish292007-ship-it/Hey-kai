package com.kai.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Kai: futuristic male AI character.
 * - Neon aankhein: band = dim, sunta hua = theme rang, command ka intezaar = hara, bolte waqt = gulabi + pulse
 * - Bolte waqt muh hilta hai (KaiVoice.speaking)
 * - Tairta hai, saans leta hai, palak jhapakta hai, tap par uchhalta hai
 */
class KaiCharacterView(ctx: Context) : View(ctx) {

    var active = false
    private var tapTime = -10000L

    fun poke() { tapTime = SystemClock.uptimeMillis() }

    private fun col(s: String) = Color.parseColor(s)
    private fun fill(c: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = c }
    private fun line(c: Int, w: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = c; style = Paint.Style.STROKE; strokeWidth = w; strokeCap = Paint.Cap.ROUND
    }

    private val pink = col("#FF4081")
    private val green = col("#00E676")
    private val offColor = col("#4A5280")

    private val skin = fill(col("#E8C3A8"))
    private val skinDark = fill(col("#CFA188"))
    private val jacket = fill(col("#141A38"))
    private val vneck = fill(col("#090D22"))
    private val socket = fill(col("#0B0F2A"))
    private val mouthIn = fill(col("#2A0F1F"))
    private val dark = fill(col("#0B0F2A"))
    private val neon = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val accentLine = line(Color.CYAN, 2f)
    private val ring = line(Color.CYAN, 1.6f)
    private val sparkle = fill(Color.WHITE)
    private val browPaint = line(col("#2B2F66"), 3.4f)
    private val mouthLine = line(col("#8A5A55"), 2.4f)
    private val noseLine = line(col("#B98B73"), 1.6f)
    private val cupFill = fill(col("#0F1430"))
    private val boom = line(Color.CYAN, 2.2f)

    private val hair = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = LinearGradient(0f, 28f, 0f, 112f, col("#6C63FF"), col("#12163A"), Shader.TileMode.CLAMP)
    }

    private val ringA = RectF(8f, 38f, 192f, 222f)
    private val ringB = RectF(20f, 50f, 180f, 210f)
    private val path = Path()

    private fun sf(x: Double) = sin(x).toFloat()

    private fun neonPaint(c: Int, a: Int): Paint {
        neon.color = c
        neon.alpha = a.coerceIn(0, 255)
        return neon
    }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val t = now / 1000.0
        val spk = KaiVoice.speaking
        val aw = KaiState.awaiting
        val run = KaiService.isRunning

        val eye = when {
            spk -> pink
            aw -> green
            run -> KaiState.themeColor
            else -> offColor
        }

        val s = min(width / 200f, height / 260f)
        c.save()
        c.translate((width - 200f * s) / 2f, (height - 260f * s) / 2f)
        c.scale(s, s)

        // Glow + ghoomti rings
        glow.color = eye
        for (k in 1..4) {
            glow.alpha = if (run || spk) 16 else 8
            c.drawCircle(100f, 130f, 114f - k * 14f, glow)
        }
        ring.color = eye
        ring.alpha = 70
        c.drawCircle(100f, 130f, 92f, ring)
        ring.alpha = 220
        val speedUp = if (spk) 2.2 else 1.0
        c.drawArc(ringA, (t * 40 * speedUp).toFloat(), 70f, false, ring)
        c.drawArc(ringA, (t * 40 * speedUp + 180).toFloat(), 40f, false, ring)
        c.drawArc(ringB, (-t * 55 * speedUp).toFloat(), 60f, false, ring)

        // Data sparkles
        for (i in 0..7) {
            val a = i * 0.8 + t * 0.3 * (if (i % 2 == 0) 1 else -1)
            val r = 96f + (i % 3) * 8f
            val x = 100f + r * cos(a).toFloat()
            val y = 130f + r * 1.05f * sin(a).toFloat()
            sparkle.color = eye
            sparkle.alpha = (120 + 120 * sin(t * 2 + i)).toInt().coerceIn(0, 255)
            c.drawCircle(x, y, 1.4f + (i % 3) * 0.6f, sparkle)
        }

        // Tap par uchhalna
        val dt = now - tapTime
        var jump = 0f
        var surprise = 0f
        if (dt in 0L..700L) {
            val k = dt / 700.0
            jump = (-abs(sin(k * PI * 2)) * 16 * (1 - k)).toFloat()
            surprise = (1 - k).toFloat() * 0.8f
        }
        val bob = sf(t * 1.6) * 4f + jump
        val breath = 1f + 0.006f * sf(t * 2.0)

        c.save()
        c.translate(0f, bob)
        c.scale(1f, breath, 100f, 262f)

        accentLine.color = eye
        boom.color = eye

        // Jacket
        path.reset()
        path.moveTo(36f, 262f)
        path.cubicTo(36f, 214f, 62f, 198f, 100f, 196f)
        path.cubicTo(138f, 198f, 164f, 214f, 164f, 262f)
        path.close()
        c.drawPath(path, jacket)
        accentLine.alpha = 200
        c.drawPath(path, accentLine)
        path.reset()
        path.moveTo(76f, 198f); path.lineTo(100f, 238f); path.lineTo(124f, 198f); path.close()
        c.drawPath(path, vneck)
        accentLine.alpha = 150
        c.drawPath(path, accentLine)
        // Chest orb
        for (k in 3 downTo 1) c.drawCircle(100f, 248f, 4f + k * 3f, neonPaint(eye, 25 * (4 - k)))
        c.drawCircle(100f, 248f, 4f, neonPaint(eye, 255))
        // Jacket tech lines
        accentLine.alpha = 110
        c.drawLine(50f, 232f, 66f, 232f, accentLine)
        c.drawLine(50f, 240f, 60f, 240f, accentLine)
        c.drawLine(150f, 232f, 134f, 232f, accentLine)
        c.drawLine(150f, 240f, 140f, 240f, accentLine)

        // Gardan + kaan
        c.drawRect(RectF(88f, 168f, 112f, 204f), skinDark)
        c.drawOval(RectF(52f, 114f, 64f, 134f), skinDark)
        c.drawOval(RectF(136f, 114f, 148f, 134f), skinDark)

        // Sar (jabda wala)
        path.reset()
        path.moveTo(58f, 104f)
        path.cubicTo(56f, 66f, 144f, 66f, 142f, 104f)
        path.lineTo(141f, 138f)
        path.quadTo(138f, 176f, 100f, 182f)
        path.quadTo(62f, 176f, 59f, 138f)
        path.close()
        c.drawPath(path, skin)

        // Cheek circuit lines
        accentLine.alpha = 150
        accentLine.strokeWidth = 1.2f
        path.reset()
        path.moveTo(64f, 132f); path.lineTo(72f, 132f); path.lineTo(76f, 138f); path.lineTo(76f, 152f)
        c.drawPath(path, accentLine)
        path.reset()
        path.moveTo(136f, 132f); path.lineTo(128f, 132f); path.lineTo(124f, 138f); path.lineTo(124f, 152f)
        c.drawPath(path, accentLine)
        c.drawCircle(76f, 152f, 1.6f, neonPaint(eye, 200))
        c.drawCircle(124f, 152f, 1.6f, neonPaint(eye, 200))
        accentLine.strokeWidth = 2f

        // Spiky baal
        path.reset()
        path.moveTo(55f, 112f); path.lineTo(50f, 84f); path.lineTo(60f, 70f); path.lineTo(60f, 48f)
        path.lineTo(78f, 62f); path.lineTo(84f, 34f); path.lineTo(98f, 58f); path.lineTo(112f, 30f)
        path.lineTo(120f, 58f); path.lineTo(138f, 42f); path.lineTo(138f, 68f); path.lineTo(152f, 80f)
        path.lineTo(146f, 112f); path.lineTo(140f, 94f); path.lineTo(126f, 88f); path.lineTo(100f, 82f)
        path.lineTo(74f, 88f); path.lineTo(60f, 94f); path.close()
        c.drawPath(path, hair)
        accentLine.alpha = 170
        c.drawPath(path, accentLine)

        // Bhauhein
        val browDy = if (aw) -4f else if (spk) sf(t * 5) * 1.2f else 0f
        c.drawLine(66f, 106f + browDy, 92f, 110f + browDy, browPaint)
        c.drawLine(134f, 106f + browDy, 108f, 110f + browDy, browPaint)

        // Neon aankhein
        val m = now % 3800
        val open = if (m < 180) 1f - sf(PI * m / 180.0) else 1f
        val ry = when {
            spk -> 6.2f + 2.2f * sf(t * 14)
            aw -> 8.5f
            run -> 6.2f
            else -> 3.2f
        }
        val coreA = if (run || spk) 255 else 130
        for (side in 0..1) {
            val ex = if (side == 0) 80f else 120f
            val rot = if (side == 0) 7f else -7f
            c.save()
            c.translate(ex, 120f)
            c.rotate(rot)
            c.scale(1f, max(open, 0.1f))
            c.drawOval(RectF(-15f, -ry - 3.5f, 15f, ry + 3.5f), socket)
            for (k in 3 downTo 1) {
                c.drawOval(
                    RectF(-(12f + k * 2.6f), -(ry + k * 2.4f), 12f + k * 2.6f, ry + k * 2.4f),
                    neonPaint(eye, (if (run || spk) 20 else 10) * (4 - k))
                )
            }
            c.drawOval(RectF(-12f, -ry, 12f, ry), neonPaint(eye, coreA))
            c.drawOval(RectF(-7f, -ry * 0.5f, 7f, ry * 0.5f), neonPaint(Color.WHITE, if (run || spk) 230 else 90))
            if (run && !spk && !aw) {
                val x = sf(t * 2.2) * 6f
                c.drawRoundRect(RectF(x - 1.2f, -ry, x + 1.2f, ry), 1f, 1f, dark)
            }
            c.restore()
        }

        // Naak
        c.drawLine(100f, 128f, 98f, 143f, noseLine)
        c.drawLine(98f, 143f, 103f, 144f, noseLine)

        // Muh: bolte waqt hilta hai
        val mouth = if (spk) abs(sf(t * 11)) * (0.55f + 0.45f * sf(t * 3.7 + 1))
        else max(surprise, if (aw) 0.18f else 0f)
        if (mouth < 0.06f) {
            if (run) {
                c.drawArc(RectF(89f, 150f, 111f, 162f), 20f, 140f, false, mouthLine)
            } else {
                c.drawLine(91f, 157f, 109f, 157f, mouthLine)
            }
        } else {
            c.drawRoundRect(RectF(90f, 152f, 110f, 152f + 3f + 13f * mouth), 6f, 6f, mouthIn)
            c.drawRect(RectF(93f, 153f, 107f, 154.6f), neonPaint(Color.WHITE, 200))
        }

        // Headset earpieces + mic boom
        for (x in floatArrayOf(42f, 144f)) {
            c.drawRoundRect(RectF(x, 108f, x + 14f, 142f), 6f, 6f, cupFill)
            accentLine.alpha = 230
            c.drawRoundRect(RectF(x, 108f, x + 14f, 142f), 6f, 6f, accentLine)
            c.drawCircle(x + 7f, 125f, 3f, neonPaint(eye, (140 + 110 * sin(t * 3)).toInt()))
        }
        path.reset()
        path.moveTo(46f, 142f); path.quadTo(48f, 166f, 74f, 166f)
        c.drawPath(path, boom)
        c.drawCircle(74f, 166f, 3f, neonPaint(eye, 255))

        c.restore()
        c.restore()
        postInvalidateOnAnimation()
    }
}
