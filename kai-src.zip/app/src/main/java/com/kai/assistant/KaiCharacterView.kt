package com.kai.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Kaira: cute anime-style AI girl (poori saree).
 * - Neon aankhein: band = dim, sunta hua = theme rang, command ka intezaar = hara, bolte waqt = gulabi + pulse
 * - Bolte waqt muh hilta hai (KaiVoice.speaking)
 * - Tairta hai, saans leta hai, palak jhapakta hai, tap par uchhalta hai
 */
class KaiCharacterView(ctx: Context) : View(ctx) {

    var active = false
    private var tapTime = -10000L

    fun poke() { tapTime = SystemClock.uptimeMillis() }

    private fun col(s: String) = Color.parseColor(s)
    private fun fill(c: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = c }
    private fun line(c: Int, w: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = c; style = Paint.Style.STROKE; strokeWidth = w; strokeCap = Paint.Cap.ROUND
    }

    private val pink = col("#FF4081")
    private val green = col("#00E676")
    private val offColor = col("#4A5280")

    private val skin = fill(col("#E8C3A8"))
    private val skinDark = fill(col("#CFA188"))
    private val jacket = fill(col("#141A38"))
    private val vneck = fill(col("#090D22"))
    private val socket = fill(col("#0B0F2A"))
    private val mouthIn = fill(col("#2A0F1F"))
    private val dark = fill(col("#0B0F2A"))
    private val neon = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val accentLine = line(Color.CYAN, 2f)
    private val ring = line(Color.CYAN, 1.6f)
    private val sparkle = fill(Color.WHITE)
    private val browPaint = line(col("#2B2F66"), 3.4f)
    private val mouthLine = line(col("#8A5A55"), 2.4f)
    private val noseLine = line(col("#B98B73"), 1.6f)
    private val cupFill = fill(col("#0F1430"))
    private val boom = line(Color.CYAN, 2.2f)

    private val hair = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = LinearGradient(0f, 28f, 0f, 112f, col("#6C63FF"), col("#12163A"), Shader.TileMode.CLAMP)
    }

    private val hairBack = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = LinearGradient(0f, 70f, 0f, 245f, col("#4A3394"), col("#150F33"), Shader.TileMode.CLAMP)
    }
    private val sareePink = fill(col("#FF6FA8"))
    private val sareeDeep = fill(col("#E91E75"))
    private val blouse = fill(col("#FFE0EC"))
    private val gold = line(col("#FFD54F"), 2f)
    private val goldFill = fill(col("#FFD54F"))
    private val sclera = fill(col("#FBF7FF"))
    private val white = fill(Color.WHITE)
    private val lash = line(col("#1B1233"), 3.4f)
    private val blush = fill(col("#FF8FB3")).apply { alpha = 120 }
    private val bindi = fill(col("#E53935"))
    private val petal = fill(col("#FFB3D1"))
    private val tongue = fill(col("#FF7A9C"))

    private val ringA = RectF(8f, 38f, 192f, 222f)
    private val ringB = RectF(20f, 50f, 180f, 210f)
    private val path = Path()

    private fun sf(x: Double) = sin(x).toFloat()

    private fun neonPaint(c: Int, a: Int): Paint {
        neon.color = c
        neon.alpha = a.coerceIn(0, 255)
        return neon
    }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val t = now / 1000.0
        val spk = KaiVoice.speaking
        val aw = KaiState.awaiting
        val run = KaiService.isRunning

        val eye = when {
            spk -> pink
            aw -> green
            run -> KaiState.themeColor
            else -> offColor
        }

        val s = min(width / 200f, height / 260f)
        c.save()
        c.translate((width - 200f * s) / 2f, (height - 260f * s) / 2f)
        c.scale(s, s)

        // Glow + ghoomti rings
        glow.color = eye
        for (k in 1..4) {
            glow.alpha = if (run || spk) 16 else 8
            c.drawCircle(100f, 130f, 114f - k * 14f, glow)
        }
        ring.color = eye
        ring.alpha = 70
        c.drawCircle(100f, 130f, 92f, ring)
        ring.alpha = 220
        val speedUp = if (spk) 2.2 else 1.0
        c.drawArc(ringA, (t * 40 * speedUp).toFloat(), 70f, false, ring)
        c.drawArc(ringA, (t * 40 * speedUp + 180).toFloat(), 40f, false, ring)
        c.drawArc(ringB, (-t * 55 * speedUp).toFloat(), 60f, false, ring)

        // Data sparkles
        for (i in 0..7) {
            val a = i * 0.8 + t * 0.3 * (if (i % 2 == 0) 1 else -1)
            val r = 96f + (i % 3) * 8f
            val x = 100f + r * cos(a).toFloat()
            val y = 130f + r * 1.05f * sin(a).toFloat()
            sparkle.color = eye
            sparkle.alpha = (120 + 120 * sin(t * 2 + i)).toInt().coerceIn(0, 255)
            c.drawCircle(x, y, 1.4f + (i % 3) * 0.6f, sparkle)
        }

        // Tap par uchhalna
        val dt = now - tapTime
        var jump = 0f
        var surprise = 0f
        if (dt in 0L..700L) {
            val k = dt / 700.0
            jump = (-abs(sin(k * PI * 2)) * 16 * (1 - k)).toFloat()
            surprise = (1 - k).toFloat() * 0.8f
        }
        val bob = sf(t * 1.6) * 4f + jump
        val breath = 1f + 0.006f * sf(t * 2.0)

        c.save()
        c.translate(0f, bob)
        c.scale(1f, breath, 100f, 262f)

        accentLine.color = eye
        val sway = sf(t * 1.3) * 3f

        // Peeche ke lambe baal
        path.reset()
        path.moveTo(52f, 110f)
        path.cubicTo(34f, 150f, 40f, 200f + sway, 46f, 238f)
        path.quadTo(100f, 252f, 154f, 238f)
        path.cubicTo(160f, 200f - sway, 166f, 150f, 148f, 110f)
        path.close()
        c.drawPath(path, hairBack)

        // Gardan
        c.drawRect(RectF(88f, 170f, 112f, 206f), skinDark)

        // Pink saree (poora dhaka hua)
        path.reset()
        path.moveTo(34f, 262f)
        path.cubicTo(34f, 216f, 62f, 198f, 100f, 196f)
        path.cubicTo(138f, 198f, 166f, 216f, 166f, 262f)
        path.close()
        c.drawPath(path, sareePink)
        // Pallu (kandhe se kamar tak)
        path.reset()
        path.moveTo(60f, 208f); path.lineTo(86f, 199f); path.lineTo(166f, 244f)
        path.lineTo(166f, 262f); path.lineTo(142f, 262f); path.close()
        c.drawPath(path, sareeDeep)
        c.drawLine(86f, 199f, 166f, 244f, gold)
        c.drawLine(60f, 208f, 142f, 262f, gold)
        // Blouse ka gol gala
        path.reset()
        path.moveTo(80f, 199f); path.quadTo(100f, 222f, 120f, 199f); path.close()
        c.drawPath(path, skinDark)
        c.drawOval(RectF(92f, 204f, 108f, 214f), skinDark)
        // Locket (neon)
        for (k in 3 downTo 1) c.drawCircle(100f, 218f, 3f + k * 2.5f, neonPaint(eye, 25 * (4 - k)))
        c.drawCircle(100f, 218f, 3.4f, neonPaint(eye, 255))
        // Saree par design
        for (i in 0..3) c.drawCircle(52f + i * 9f, 244f - i * 3f, 1.8f, goldFill)

        // Kaan
        c.drawOval(RectF(52f, 118f, 64f, 138f), skinDark)
        c.drawOval(RectF(136f, 118f, 148f, 138f), skinDark)

        // Chehra
        path.reset()
        path.moveTo(58f, 108f)
        path.cubicTo(56f, 70f, 144f, 70f, 142f, 108f)
        path.lineTo(141f, 140f)
        path.quadTo(138f, 178f, 100f, 186f)
        path.quadTo(62f, 178f, 59f, 140f)
        path.close()
        c.drawPath(path, skin)

        // Gaalon ki laali
        c.drawOval(RectF(62f, 148f, 80f, 158f), blush)
        c.drawOval(RectF(120f, 148f, 138f, 158f), blush)

        // Aage ke baal + bangs
        path.reset()
        path.moveTo(50f, 130f)
        path.cubicTo(40f, 60f, 160f, 60f, 150f, 130f)
        path.lineTo(143f, 108f)
        path.quadTo(128f, 100f, 112f, 84f)
        path.quadTo(98f, 104f, 76f, 102f)
        path.quadTo(62f, 106f, 57f, 132f)
        path.close()
        c.drawPath(path, hair)
        // Side locks
        path.reset()
        path.moveTo(52f, 112f); path.quadTo(40f, 170f, 54f, 204f); path.quadTo(64f, 164f, 64f, 124f); path.close()
        c.drawPath(path, hair)
        path.reset()
        path.moveTo(148f, 112f); path.quadTo(160f, 170f, 146f, 204f); path.quadTo(136f, 164f, 136f, 124f); path.close()
        c.drawPath(path, hair)
        accentLine.alpha = 120
        c.drawArc(RectF(66f, 64f, 134f, 96f), 200f, 70f, false, accentLine)

        // Bindi
        c.drawCircle(100f, 104f, 2.4f, bindi)

        // Bhauhein
        val browDy = if (aw) -3f else if (spk) sf(t * 5) * 1.2f else 0f
        c.drawLine(66f, 112f + browDy, 90f, 114f + browDy, browPaint)
        c.drawLine(134f, 112f + browDy, 110f, 114f + browDy, browPaint)

        // Bade anime neon aankhein
        val m = now % 3800
        val open = if (m < 180) 1f - sf(PI * m / 180.0) else 1f
        val iris = when {
            spk -> 10f + 1.2f * sf(t * 12)
            aw -> 11.5f
            run -> 10f
            else -> 8f
        }
        val lookX = if (run && !spk && !aw) sf(t * 0.9) * 2.2f else 0f
        for (side in 0..1) {
            val ex = if (side == 0) 79f else 121f
            c.save()
            c.translate(ex, 130f)
            c.scale(1f, max(open, 0.1f))
            c.drawOval(RectF(-18f, -19f, 18f, 19f), neonPaint(eye, if (run || spk) 38 else 14))
            c.drawOval(RectF(-13f, -14f, 13f, 14f), sclera)
            c.drawOval(RectF(lookX - iris, -iris - 1f, lookX + iris, iris + 3f), neonPaint(eye, if (run || spk) 255 else 140))
            c.drawOval(RectF(lookX - 4.2f, -5f, lookX + 4.2f, 6f), dark)
            c.drawCircle(lookX - 4f, -6f, 3.2f, white)
            c.drawCircle(lookX + 4f, 5f, 1.6f, white)
            c.drawArc(RectF(-14f, -15f, 14f, 13f), 188f, 164f, false, lash)
            c.restore()
        }

        // Naak
        c.drawLine(100f, 148f, 99f, 152f, noseLine)

        // Muh: bolte waqt hilta hai
        val mouth = if (spk) abs(sf(t * 11)) * (0.55f + 0.45f * sf(t * 3.7 + 1))
        else max(surprise, if (aw) 0.18f else 0f)
        if (mouth < 0.06f) {
            if (run) {
                c.drawArc(RectF(92f, 155f, 108f, 166f), 20f, 140f, false, mouthLine)
            } else {
                c.drawLine(93f, 161f, 107f, 161f, mouthLine)
            }
        } else {
            c.drawRoundRect(RectF(93f, 156f, 107f, 156f + 3f + 11f * mouth), 6f, 6f, mouthIn)
            if (mouth > 0.4f) c.drawOval(RectF(96f, 156f + 11f * mouth, 104f, 159f + 11f * mouth), tongue)
        }

        // Jhumke
        for (x in floatArrayOf(56f, 144f)) {
            c.drawCircle(x, 142f, 2.2f, goldFill)
            c.drawCircle(x, 150f, 3.4f, neonPaint(eye, (150 + 100 * sin(t * 3)).toInt()))
        }

        // Baalon me phool
        for (k in 0..4) {
            val a = k * 2 * PI / 5 + t * 0.4
            c.drawCircle(130f + 6f * cos(a).toFloat(), 90f + 6f * sin(a).toFloat(), 4.2f, petal)
        }
        c.drawCircle(130f, 90f, 3.4f, neonPaint(eye, 255))

        c.restore()
        c.restore()
        postInvalidateOnAnimation()
    }
}
