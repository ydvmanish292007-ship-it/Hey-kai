package com.kai.assistant

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.View
import kotlin.math.*

/** KAI: animated male cyberpunk character drawn entirely with Android Canvas (no character image asset). */
class KaiCharacterView(ctx: Context) : View(ctx) {
    var active = false
    /** UI state: IDLE, LISTENING, THINKING, SPEAKING. */
    var characterState: String = "IDLE"
    private var tapTime = -10000L
    fun poke() { tapTime = SystemClock.uptimeMillis(); invalidate() }

    private fun color(hex: String) = Color.parseColor(hex)
    private fun paint(hex: String) = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = color(hex) }
    private fun stroke(hex: String, w: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = color(hex); style = Paint.Style.STROKE; strokeWidth = w; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }

    private val cyan = color("#00E5FF")
    private val purple = color("#9C4DFF")
    private val skin = paint("#D99A78")
    private val skinShade = paint("#A96552")
    private val white = paint("#F4F7FF")
    private val dark = paint("#101426")
    private val jacket = paint("#151B32")
    private val accentFill = paint("#8B38FF")
    private val hair = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = LinearGradient(35f, 35f, 160f, 130f,
            intArrayOf(color("#080D20"), color("#26345E"), color("#087EAB")), null, Shader.TileMode.CLAMP)
    }
    private val iris = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = LinearGradient(0f, -10f, 0f, 10f, cyan, purple, Shader.TileMode.CLAMP)
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = stroke("#00E5FF", 1.8f)
    private val trim = stroke("#00DFFF", 2.2f)
    private val path = Path()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val now = SystemClock.uptimeMillis()
        val t = now / 1000.0
        val s = min(width / 200f, height / 270f)
        if (s <= 0f) return
        canvas.save()
        canvas.translate((width - 200f * s) / 2f, (height - 270f * s) / 2f)
        canvas.scale(s, s)
        val sharedState = KaiCharacterState.state
        val state = when {
            sharedState != "IDLE" -> sharedState
            characterState != "IDLE" -> characterState
            active -> "LISTENING"
            else -> "IDLE"
        }
        val accent = when (state) {
            "LISTENING" -> color("#00FFB3")
            "SPEAKING" -> color("#FF4DFF")
            "THINKING" -> color("#FFC857")
            else -> cyan
        }
        val listeningPulse = if (state == "LISTENING") (sin(t * 8).toFloat() + 1f) / 2f else 0f
        val mouthOpen = if (state == "SPEAKING") (3f + abs(sin(t * 13)).toFloat() * 8f) else 0f

        glow.shader = RadialGradient(100f, 130f, 115f, intArrayOf(0x553C27FF, 0x2200DFFF, Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        canvas.drawCircle(100f, 132f, 116f, glow)
        ring.color = accent
        ring.alpha = if (state == "LISTENING") (100 + listeningPulse * 130).toInt() else 90
        canvas.drawCircle(100f, 132f, 91f + listeningPulse * 4f, ring)
        ring.alpha = 230
        canvas.drawArc(RectF(8f, 40f, 192f, 224f), (t * 35).toFloat(), 72f, false, ring)
        canvas.drawArc(RectF(18f, 50f, 182f, 214f), (-t * 48).toFloat(), 48f, false, ring)
        for (i in 0..9) {
            val a = i * 0.72 + t * (if (i % 2 == 0) 0.25 else -0.2)
            val r = 98f + (i % 3) * 7f
            val p = paint("#FFFFFF"); p.alpha = (100 + 150 * abs(sin(t * 2 + i))).toInt().coerceIn(0, 255)
            canvas.drawCircle(100f + cos(a).toFloat() * r, 132f + sin(a).toFloat() * r, 1.5f + (i % 3) * .5f, p)
        }

        val dt = now - tapTime
        val jump = if (dt in 0L..650L) (-abs(sin(dt / 650.0 * PI * 2)) * 10 * (1 - dt / 650.0)).toFloat() else 0f
        val bob = sin(t * 1.5).toFloat() * 3.5f + jump
        canvas.save(); canvas.translate(0f, bob)

        // Short swept-back hair silhouette
        canvas.drawOval(RectF(49f, 48f, 151f, 153f), hair)
        // shoulders and futuristic hoodie
        path.reset(); path.moveTo(37f, 267f); path.cubicTo(39f, 216f, 58f, 196f, 79f, 192f)
        path.lineTo(100f, 207f); path.lineTo(121f, 192f); path.cubicTo(147f, 197f, 162f, 220f, 164f, 267f); path.close()
        canvas.drawPath(path, jacket); canvas.drawPath(path, trim)
        path.reset(); path.moveTo(77f, 196f); path.lineTo(100f, 231f); path.lineTo(123f, 196f); path.lineTo(116f, 267f); path.lineTo(84f, 267f); path.close()
        canvas.drawPath(path, dark)
        canvas.drawRoundRect(RectF(92f, 232f, 108f, 250f), 4f, 4f, accentFill)
        canvas.drawCircle(100f, 241f, 3f, paint("#FFFFFF"))
        // neck
        canvas.drawRoundRect(RectF(88f, 164f, 112f, 203f), 7f, 7f, skinShade)
        // masculine face: narrower chin, angular jaw
        path.reset(); path.moveTo(56f, 83f); path.quadTo(57f, 58f, 100f, 58f); path.quadTo(143f, 58f, 144f, 83f)
        path.lineTo(137f, 137f); path.quadTo(130f, 165f, 100f, 178f); path.quadTo(70f, 165f, 63f, 137f); path.close()
        canvas.drawPath(path, skin)
        // ears
        canvas.drawRoundRect(RectF(48f, 105f, 64f, 133f), 6f, 6f, skinShade)
        canvas.drawRoundRect(RectF(136f, 105f, 152f, 133f), 6f, 6f, skinShade)
        // side hair and sharp fringe
        path.reset(); path.moveTo(51f, 108f); path.quadTo(38f, 60f, 76f, 43f); path.quadTo(118f, 27f, 151f, 59f)
        path.quadTo(163f, 78f, 148f, 119f); path.lineTo(135f, 93f); path.lineTo(123f, 105f)
        path.lineTo(112f, 78f); path.lineTo(96f, 101f); path.lineTo(83f, 78f); path.lineTo(68f, 105f); path.lineTo(62f, 130f); path.close()
        canvas.drawPath(path, hair)
        canvas.drawPath(Path().apply { moveTo(73f, 54f); quadTo(104f, 39f, 135f, 59f) }, stroke("#537DFF", 2f))
        // eyebrows, focused eyes
        val brow = stroke("#25223A", 3.5f)
        canvas.drawPath(Path().apply { moveTo(67f, 105f); quadTo(79f, 98f, 89f, 105f) }, brow)
        canvas.drawPath(Path().apply { moveTo(111f, 105f); quadTo(123f, 98f, 134f, 105f) }, brow)
        for (ex in floatArrayOf(79f, 121f)) {
            val eyeGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = accent; alpha = if (state == "LISTENING") (70 + listeningPulse * 100).toInt() else 65
                maskFilter = BlurMaskFilter(7f, BlurMaskFilter.Blur.NORMAL)
            }
            canvas.drawOval(RectF(ex - 12f, 107f, ex + 12f, 129f), eyeGlow)
            canvas.drawOval(RectF(ex - 11f, 108f, ex + 11f, 128f), white)
            canvas.drawOval(RectF(ex - 7f, 109f, ex + 7f, 127f), iris)
            canvas.drawOval(RectF(ex - 3.5f, 111f, ex + 3.5f, 124f), dark)
            canvas.drawCircle(ex - 2.5f, 114f, 2.4f, white)
        }
        // nose and confident mouth
        canvas.drawPath(Path().apply { moveTo(100f, 119f); lineTo(96f, 137f); lineTo(103f, 139f) }, stroke("#A96552", 2f))
        if (state == "SPEAKING") {
            canvas.drawRoundRect(RectF(91f, 150f, 109f, 151f + mouthOpen), 4f, 4f, paint("#35152D"))
            canvas.drawRoundRect(RectF(94f, 151f, 106f, 153f + mouthOpen * .35f), 2f, 2f, paint("#FF8EAD"))
        } else {
            canvas.drawPath(Path().apply {
                moveTo(89f, 151f)
                if (state == "THINKING") quadTo(100f, 147f, 111f, 151f) else quadTo(100f, 157f, 111f, 151f)
            }, stroke("#743E3B", 2.5f))
        }
        // tiny state label makes the character feel alive
        val label = when (state) { "LISTENING" -> "LISTENING"; "SPEAKING" -> "SPEAKING"; "THINKING" -> "THINKING"; else -> "KAI ONLINE" }
        val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent; textSize = 7f; textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif-medium", Typeface.BOLD) }
        canvas.drawText(label, 100f, 187f, labelPaint)
        // subtle jawline and cyber ear pieces
        canvas.drawPath(Path().apply { moveTo(66f, 139f); quadTo(72f, 163f, 91f, 171f) }, stroke("#EAB49A", 1.5f))
        canvas.drawArc(RectF(45f, 40f, 155f, 160f), 180f, 180f, false, stroke(accent, 4f))
        for (x in floatArrayOf(43f, 143f)) {
            canvas.drawRoundRect(RectF(x, 104f, x + 15f, 139f), 5f, 5f, dark)
            canvas.drawRoundRect(RectF(x, 104f, x + 15f, 139f), 5f, 5f, stroke(accent, 2f))
            canvas.drawCircle(x + 7.5f, 121f, 3f, paint("#FFFFFF"))
        }
        // jacket tech seams
        canvas.drawPath(Path().apply { moveTo(48f, 225f); lineTo(71f, 236f); lineTo(78f, 266f) }, stroke("#9C4DFF", 2f))
        canvas.drawPath(Path().apply { moveTo(152f, 225f); lineTo(129f, 236f); lineTo(122f, 266f) }, trim)
        canvas.restore(); canvas.restore()
        postInvalidateOnAnimation()
    }
}
