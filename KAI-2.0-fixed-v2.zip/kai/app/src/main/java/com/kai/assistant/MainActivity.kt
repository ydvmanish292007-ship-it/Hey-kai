package com.kai.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private val bgTop = Color.parseColor("#0A0E1F")
    private val bgBot = Color.parseColor("#17102E")
    private val card = Color.parseColor("#141A2E")
    private val cyan = Color.parseColor("#00E5FF")
    private val green = Color.parseColor("#00E676")
    private val grey = Color.parseColor("#8E98B5")
    private val purple = Color.parseColor("#7C4DFF")

    private lateinit var character: KaiCharacterView
    private lateinit var pages: List<View>
    private val navIcons = ArrayList<TextView>()
    private val navLabels = ArrayList<TextView>()
    private lateinit var greeting: TextView
    private lateinit var statusLine: TextView
    private lateinit var cardAccess: TextView
    private lateinit var cardMode: TextView
    private lateinit var talkSub: TextView
    private lateinit var orb: FrameLayout
    private lateinit var orbBg: GradientDrawable
    private lateinit var rowMic: TextView
    private lateinit var rowAcc: TextView
    private lateinit var rowSvc: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun round(color: Int, r: Int, stroke: Int = 0, strokeColor: Int = 0) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(r).toFloat()
            if (stroke > 0) setStroke(dp(stroke), strokeColor)
        }

    private fun lp(top: Int = 0) =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(top) }

    private fun cardBox() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(16), dp(18), dp(16))
        background = round(card, 20)
    }

    private fun scroll(content: View) = ScrollView(this).apply {
        isFillViewport = true
        addView(content)
    }

    private fun page() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(20), dp(18), dp(24))
    }

    private val prefs by lazy { getSharedPreferences("kai", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bgTop
        window.navigationBarColor = Color.parseColor("#0F1424")

        pages = listOf(buildHome(), buildSetup(), buildCommands(), buildSettings())

        val container = FrameLayout(this)
        pages.forEach { container.addView(it, FrameLayout.LayoutParams(-1, -1)) }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(bgTop, bgBot))
        }
        root.addView(container, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(buildBar(), LinearLayout.LayoutParams(-1, dp(72)))
        setContentView(root)
        showPage(0)
    }

    // ---------------- HOME ----------------
    private fun buildHome(): View {
        val col = page()

        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(View(this), LinearLayout.LayoutParams(dp(40), dp(40)))
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        mid.addView(tv("KAI", 20f, Color.WHITE, true).apply { letterSpacing = 0.3f })
        mid.addView(tv("PERSONAL AI", 10f, grey).apply { letterSpacing = 0.25f })
        header.addView(mid, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(ImageView(this).apply { setImageResource(R.drawable.ic_kai_logo) },
            LinearLayout.LayoutParams(dp(40), dp(40)))
        col.addView(header, lp())

        greeting = tv("", 20f, Color.WHITE, true)
        col.addView(greeting, lp(18))
        statusLine = tv("", 13f, grey)
        col.addView(statusLine, lp(2))

        character = KaiCharacterView(this).apply {
            setOnClickListener {
                poke()
                Toast.makeText(this@MainActivity, "Hey! Main sun raha hoon \uD83D\uDE04", Toast.LENGTH_SHORT).show()
            }
        }
        col.addView(character, LinearLayout.LayoutParams(-1, dp(340)).apply { topMargin = dp(4) })

        // Quick action chips
        val chips = LinearLayout(this)
        listOf(
            "\uD83D\uDCF7 Instagram" to "open instagram",
            "\u25B6\uFE0F YouTube" to "open youtube",
            "\uD83D\uDCAC WhatsApp" to "open whatsapp",
            "\u25C0 Back" to "back",
            "\uD83C\uDFE0 Home" to "home",
            "\u2B07 Scroll" to "scroll down"
        ).forEach { (label, cmd) ->
            chips.addView(tv(label, 13f, Color.WHITE).apply {
                setPadding(dp(16), dp(10), dp(16), dp(10))
                background = round(Color.parseColor("#101629"), 20, 1, Color.parseColor("#26FFFFFF"))
                setOnClickListener { CommandHandler.handle(this@MainActivity, cmd) }
            }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) })
        }
        col.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(chips)
        }, lp(8))

        // Info cards
        val cards = LinearLayout(this)
        fun info(title: String): TextView {
            val b = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = round(card, 16, 1, Color.parseColor("#1AFFFFFF"))
            }
            b.addView(tv(title, 9f, grey).apply { letterSpacing = 0.15f })
            val v = tv("", 18f, Color.WHITE, true)
            b.addView(v, lp(4))
            cards.addView(b, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(8) })
            return v
        }
        cardAccess = info("ACCESS")
        val today = info("TODAY")
        today.text = SimpleDateFormat("d MMM", Locale.ENGLISH).format(Date())
        cardMode = info("MODE")
        col.addView(cards, lp(14))

        // Talk bar
        val talk = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(12), dp(12))
            background = round(card, 18, 1, Color.parseColor("#1AFFFFFF"))
            setOnClickListener { onMicClick() }
        }
        val tcol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        tcol.addView(tv("Talk to Kai", 14f, Color.WHITE, true))
        talkSub = tv("", 11f, grey)
        tcol.addView(talkSub)
        talk.addView(tcol, LinearLayout.LayoutParams(0, -2, 1f))
        talk.addView(tv("\uD83C\uDF99\uFE0F", 20f, Color.WHITE).apply {
            gravity = Gravity.CENTER
            background = round(Color.parseColor("#1F00E5FF"), 14, 1, cyan)
        }, LinearLayout.LayoutParams(dp(46), dp(46)))
        col.addView(talk, lp(10))

        return scroll(col)
    }

    // ---------------- SETUP ----------------
    private fun buildSetup(): View {
        val col = page()
        col.addView(tv("Setup", 24f, Color.WHITE, true))
        col.addView(tv("Teeno cheezein \u2705 honi chahiye. Line par tap karke theek karo.", 13f, grey), lp(4))
        val b = cardBox()
        rowMic = tv("", 16f, Color.WHITE).apply { setPadding(0, dp(10), 0, dp(10)); setOnClickListener { askMic() } }
        rowAcc = tv("", 16f, Color.WHITE).apply { setPadding(0, dp(10), 0, dp(10)); setOnClickListener { openAccessibility() } }
        rowSvc = tv("", 16f, Color.WHITE).apply { setPadding(0, dp(10), 0, dp(10)); setOnClickListener { onMicClick() } }
        b.addView(rowMic); b.addView(rowAcc); b.addView(rowSvc)
        col.addView(b, lp(16))
        col.addView(tv("Tip: Accessibility grey ho to Settings \u2192 Apps \u2192 Kai \u2192 \u22EE \u2192 Allow restricted settings. Battery me Kai ko No restrictions do.", 12f, grey), lp(14))
        col.addView(tv("TEST: open Instagram (bina awaaz)", 14f, cyan).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(14))
            background = round(Color.parseColor("#1A00E5FF"), 14, 1, cyan)
            setOnClickListener { CommandHandler.handle(this@MainActivity, "open instagram") }
        }, lp(18))
        return scroll(col)
    }

    // ---------------- COMMANDS ----------------
    private fun buildCommands(): View {
        val col = page()
        col.addView(tv("Kya bol sakte ho", 24f, Color.WHITE, true))
        col.addView(tv("Pehle \"Hey Kai\" bolo, phir command.", 13f, grey), lp(4))
        val b = cardBox()
        listOf(
            "Hey Kai, open Instagram",
            "Hey Kai, Instagram kholo",
            "Hey Kai, back / home / recents",
            "Hey Kai, notifications",
            "Hey Kai, scroll down / scroll up",
            "Hey Kai, click Follow",
            "Hey Kai, type hello"
        ).forEach { b.addView(tv("\u2022  $it", 15f, Color.WHITE).apply { setPadding(0, dp(8), 0, dp(8)) }) }
        col.addView(b, lp(16))
        col.addView(tv("Sirf \"Hey Kai\" bolo, beep aaye, phir command bolo.", 12f, grey), lp(12))
        return scroll(col)
    }

    // ---------------- SETTINGS ----------------
    private fun buildSettings(): View {
        val col = page()
        col.addView(tv("Settings", 24f, Color.WHITE, true))
        val b = cardBox()
        b.addView(tv("Tumhara naam", 13f, grey))
        val input = EditText(this).apply {
            setText(prefs.getString("name", ""))
            hint = "Jaise: Manish"
            setTextColor(Color.WHITE)
            setHintTextColor(grey)
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine()
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = round(Color.parseColor("#0F1424"), 12, 1, Color.parseColor("#26FFFFFF"))
        }
        b.addView(input, lp(8))
        b.addView(tv("Save", 15f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(12))
            background = round(purple, 12)
            setOnClickListener {
                prefs.edit().putString("name", input.text.toString().trim()).apply()
                refresh()
                Toast.makeText(this@MainActivity, "Save ho gaya", Toast.LENGTH_SHORT).show()
            }
        }, lp(12))
        col.addView(b, lp(16))
        val about = cardBox()
        about.addView(tv("Wake word: Hey Kai", 14f, Color.WHITE))
        about.addView(tv("Kai v1.0", 12f, grey), lp(4))
        col.addView(about, lp(12))
        return scroll(col)
    }

    // ---------------- BOTTOM BAR ----------------
    private fun buildBar(): View {
        val bar = LinearLayout(this).apply {
            clipChildren = false
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#0F1424"))
                val r = dp(22).toFloat()
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            }
        }
        fun cell(icon: String, label: String, page: Int): View {
            val c = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setOnClickListener { showPage(page) }
            }
            val i = tv(icon, 20f, grey)
            val l = tv(label, 10f, grey)
            navIcons.add(i); navLabels.add(l)
            c.addView(i); c.addView(l)
            return c
        }
        bar.addView(cell("\uD83C\uDFE0", "Home", 0), LinearLayout.LayoutParams(0, -1, 1f))
        bar.addView(cell("\uD83D\uDEE0\uFE0F", "Setup", 1), LinearLayout.LayoutParams(0, -1, 1f))

        orbBg = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#FF9100"), Color.parseColor("#FF3D00"))).apply { shape = GradientDrawable.OVAL }
        orb = FrameLayout(this).apply {
            background = orbBg
            elevation = dp(8).toFloat()
            translationY = -dp(14).toFloat()
            setOnClickListener { onMicClick() }
            addView(View(context).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
            }, FrameLayout.LayoutParams(dp(16), dp(16), Gravity.CENTER))
        }
        val orbWrap = FrameLayout(this).apply { clipChildren = false }
        orbWrap.addView(orb, FrameLayout.LayoutParams(dp(66), dp(66), Gravity.CENTER))
        bar.addView(orbWrap, LinearLayout.LayoutParams(0, -1, 1f))

        bar.addView(cell("\uD83D\uDCD6", "Commands", 2), LinearLayout.LayoutParams(0, -1, 1f))
        bar.addView(cell("\u2699\uFE0F", "Settings", 3), LinearLayout.LayoutParams(0, -1, 1f))
        return bar
    }

    private fun showPage(i: Int) {
        pages.forEachIndexed { idx, v -> v.visibility = if (idx == i) View.VISIBLE else View.GONE }
        navIcons.forEachIndexed { idx, v -> v.alpha = if (idx == i) 1f else 0.5f }
        navLabels.forEachIndexed { idx, v -> v.setTextColor(if (idx == i) cyan else grey) }
    }

    // ---------------- LOGIC ----------------
    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun hasMic() =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun askMic() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        requestPermissions(perms.toTypedArray(), 1)
    }

    private fun openAccessibility() =
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        refresh()
    }

    private fun onMicClick() {
        when {
            !hasMic() -> askMic()
            KaiAccessibilityService.instance == null -> {
                Toast.makeText(this, "Accessibility me Kai ON karo", Toast.LENGTH_LONG).show()
                openAccessibility()
            }
            KaiService.isRunning -> {
                stopService(Intent(this, KaiService::class.java))
                KaiService.isRunning = false
            }
            else -> startForegroundService(Intent(this, KaiService::class.java))
        }
        orb.postDelayed({ refresh() }, 600)
    }

    private fun row(t: TextView, ok: Boolean, label: String) {
        t.text = (if (ok) "\u2705  " else "\u2B1C  ") + label
        t.setTextColor(if (ok) green else Color.WHITE)
    }

    private fun refresh() {
        val mic = hasMic()
        val acc = KaiAccessibilityService.instance != null
        val run = KaiService.isRunning

        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val hello = when {
            h < 12 -> "Good morning"
            h < 17 -> "Good afternoon"
            else -> "Good evening"
        }
        val name = prefs.getString("name", "") ?: ""
        greeting.text = if (name.isEmpty()) "$hello \u2728" else "$hello, $name \u2728"

        statusLine.text = when {
            run -> "\u25CF Sun raha hoon... \"Hey Kai\" bolo"
            mic && acc -> "\u25CF Ready when you are"
            else -> "\u25CF Pehle Setup poora karo"
        }
        statusLine.setTextColor(if (run) green else grey)

        cardAccess.text = if (acc) "On" else "Off"
        cardAccess.setTextColor(if (acc) green else Color.parseColor("#FF5252"))
        cardMode.text = if (run) "Listening" else "Idle"
        cardMode.setTextColor(if (run) green else Color.WHITE)
        talkSub.text = if (run) "Tap karke band karo" else "Tap to start"

        row(rowMic, mic, "Mic permission")
        row(rowAcc, acc, "Accessibility ON (Kai chuno)")
        row(rowSvc, run, "Kai chalu hai")

        character.active = run
        orbBg.colors = if (run)
            intArrayOf(Color.parseColor("#00E676"), Color.parseColor("#00B8D4"))
        else
            intArrayOf(Color.parseColor("#FF9100"), Color.parseColor("#FF3D00"))
    }
}
