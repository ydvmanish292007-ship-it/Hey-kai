package com.kai.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale
import android.os.Bundle
import android.widget.Toast

class KaiService : Service() {

    companion object {
        @Volatile
        var isRunning = false
        @Volatile private var instance: KaiService? = null
        fun speak(text: String) { instance?.speakReply(text) }
    }

    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var awaitingCommand = false
    private var running = false

    // "hey kai" ke alag alag sunai dene wale roop
    private val wakeRegex = Regex("(hey|hay|hi|ok|okay|he|a)\\s+(kai|kay|ky|kaye|kae|kya|ki|kaai|kye|kia|kei|kaay)\\b")

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("en", "IN")
                tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { KaiCharacterState.state = "SPEAKING" }
                    override fun onDone(utteranceId: String?) {
                        KaiCharacterState.state = if (running) "LISTENING" else "IDLE"
                        if (running) handler.postDelayed({ startListening() }, 350)
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        KaiCharacterState.state = if (running) "LISTENING" else "IDLE"
                        if (running) handler.postDelayed({ startListening() }, 350)
                    }
                })
            }
        }
    }

    private fun speakReply(text: String) {
        val engine = tts ?: return
        if (engine.isSpeaking) engine.stop()
        KaiCharacterState.state = "SPEAKING"
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kai_reply_${System.currentTimeMillis()}")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        isRunning = true
        if (!running) {
            running = true
            startListening()
        }
        return START_STICKY
    }

    private fun startAsForeground() {
        val channelId = "kai"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Kai", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, channelId)
            .setContentTitle("Kai sun raha hai")
            .setContentText("\"Hey Kai\" bolo")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    private fun startListening() {
        if (!running) return
        KaiCharacterState.state = "LISTENING"
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(listener)
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN") // Hinglish ke liye theek chalta hai
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        recognizer?.startListening(i)
    }

    private fun restartSoon(delay: Long = 400) {
        handler.postDelayed({ startListening() }, delay)
    }

    private val listener = object : RecognitionListener {
        override fun onResults(results: Bundle?) {
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                ?.lowercase()
                ?.trim()
            if (!text.isNullOrEmpty()) process(text)
            if (tts?.isSpeaking != true) restartSoon()
        }

        override fun onError(error: Int) {
            // 6 = kuch bola nahi, 7 = samajh nahi aaya (normal). Baaki errors dikhao.
            if (error != 6 && error != 7 && error != 8) {
                Toast.makeText(this@KaiService, "Kai error code: $error", Toast.LENGTH_SHORT).show()
            }
            if (tts?.isSpeaking != true) {
                restartSoon(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 700)
            }
        }

        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() { KaiCharacterState.state = "THINKING" }
        override fun onRmsChanged(rmsdB: Float) {
            // React to the user's voice without repeatedly recreating the recognizer.
            if (running) KaiCharacterState.state = "LISTENING"
        }
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { KaiCharacterState.state = "THINKING" }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun process(text: String) {
        val cleaned = text.lowercase().replace(Regex("[,.!?;:]+"), " ").replace(Regex("\\s+"), " ").trim()
        Toast.makeText(this, "Suna: $cleaned", Toast.LENGTH_SHORT).show()
        val match = wakeRegex.find(cleaned)
        when {
            match != null -> {
                val command = cleaned.substring(match.range.last + 1).trim()
                if (command.isEmpty()) {
                    awaitingCommand = true
                    beep()
                } else {
                    awaitingCommand = false
                    KaiCharacterState.state = "THINKING"
                    CommandHandler.handle(this, command)
                }
            }
            awaitingCommand -> {
                awaitingCommand = false
                KaiCharacterState.state = "THINKING"
                CommandHandler.handle(this, cleaned)
            }
        }
    }

    private fun beep() {
        ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 150)
    }

    override fun onDestroy() {
        running = false
        isRunning = false
        KaiCharacterState.state = "IDLE"
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        tts = null
        instance = null
        super.onDestroy()
    }
}
