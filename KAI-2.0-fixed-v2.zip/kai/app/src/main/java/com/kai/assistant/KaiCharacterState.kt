package com.kai.assistant

/** Shared animated character state used by the UI and voice service. */
object KaiCharacterState {
    @Volatile var state: String = "IDLE"
}
