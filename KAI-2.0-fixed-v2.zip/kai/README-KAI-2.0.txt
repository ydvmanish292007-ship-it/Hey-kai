KAI 2.0 — LIVING AI CHARACTER

Project features
- Cyberpunk character drawn using Android Canvas (no external character image required).
- Animated character states: IDLE, LISTENING, THINKING, SPEAKING.
- Mouth animation while Android TextToSpeech is speaking.
- Reactive neon and eye effects while listening/thinking/speaking.
- Voice command examples: “Hey Kai, open Instagram”, “back”, “home”, “scroll down”, “click Follow”, “type hello”.
- Setup screen for microphone permission and Accessibility Service.
- GitHub Actions workflow builds a debug APK and uploads it as an artifact.

Build on GitHub
1. Upload/push the CONTENTS of this project folder to the root of a GitHub repository (the root must contain settings.gradle.kts and app/).
2. Open the repository's Actions tab.
3. Run “Build KAI Android APK” using Run workflow, or push to main/master.
4. Open the completed workflow run and download the “KAI-2.0-debug-apk” artifact.

Local build
Requires JDK 17 and Gradle 8.7. From this folder run:
  gradle assembleDebug

Phone setup
1. Install the debug APK.
2. Grant Microphone permission.
3. Open Android Settings > Accessibility and enable KAI AI.
4. Return to KAI and tap the central button to start/stop listening.
5. Try: “Hey Kai, open Instagram” or “Hey Kai, open WhatsApp”.

Important notes
- This archive does not include Gradle Wrapper files; the GitHub workflow installs Gradle 8.7 directly.
- A full Android build could not be executed in the current environment because the Android SDK and Gradle are not installed here. The workflow is provided to perform the real build on GitHub; successful compilation is not guaranteed until that workflow passes.
- Speech recognition depends on the speech service and language support available on the phone.
- Accessibility access is powerful. Enable it only if you understand and consent to the actions KAI can perform on-screen.
