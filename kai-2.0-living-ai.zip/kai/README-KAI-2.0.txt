KAI 2.0 source update

Included: male cyberpunk Canvas character animation; listening/thinking/speaking states; animated mouth while Android TextToSpeech speaks; reactive neon/eye effects; command cleanup for punctuation; app name aliases for Instagram, WhatsApp, YouTube, Chrome, Camera, and Telegram; voice feedback for open/back/home commands.

Build: Open this project folder in Android Studio, allow Gradle sync, then Build > Build APK(s). This source archive does not include Gradle Wrapper files. A successful build has not been verified in this environment because Gradle/Android SDK are unavailable here.

Phone setup: grant Microphone permission and enable KAI AI in Android Settings > Accessibility. Start the voice service from the app. Test with “Hey Kai, open Instagram” or “Hey Kai, open WhatsApp”. Android speech recognition availability/language behavior depends on the device.
